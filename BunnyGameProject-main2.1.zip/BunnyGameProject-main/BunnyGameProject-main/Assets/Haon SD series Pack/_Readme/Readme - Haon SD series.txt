This package was created by 'HaonStore'.
Support : haonstore@gmail.com
F&Q : https://haonstore.notion.site/

[F&Q]
- Guide: How to Import Unity-Chan Spring Bone
https://www.notion.so/haonstore/Guide-How-to-Import-Unity-Chan-Spring-Bone-ba018ac89dfd432fb11a606d470baf02

- Guide: How to Import Unity Toon Shader
https://www.notion.so/haonstore/Guide-How-to-Import-Unity-Toon-Shader-19ba5026cf5480239cced146e014f780

[License]
- The character IP is a derivative of the source of 'Unity-chan' provided by Unity Technology Japan. The 'Unity-chan License' applies to the elements that make up the character's core, such as character identity and character design.
- Other assets follow the end user license provided by the market.
- Please refer to the Unity-chan homepage to see how far the Unity-chan license applies. This scope of application is updated when the license is updated, so it is most accurate to check through the Unity-chan official homepage and customer inquiries.
https://unity-chan.com/contents/guideline/